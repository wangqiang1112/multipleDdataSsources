package com.lonelywolf.boot.study.javathinking.vessel;



/**
 * @Author: Xiangyong.zeng
 * @Date: 2019-07-28 15:02
 * @Description:
 */
public class CollectionVessel {


}
