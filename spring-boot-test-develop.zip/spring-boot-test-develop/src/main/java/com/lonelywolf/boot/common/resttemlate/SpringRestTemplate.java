package com.lonelywolf.boot.common.resttemlate;

import org.springframework.web.client.RestTemplate;

/**
 * @Author: Xiangyong.zeng
 * @Date: 2019-08-01 11:22
 * @Description:
 */
public class SpringRestTemplate extends RestTemplate{


}
