package com.lonelywolf.boot.linuxdatasource.mydemo.service;

/**
 * @Author: Xiangyong.zeng
 * @Date: 2019-08-01 11:24
 * @Description:
 */
public interface IGainNewData {

    boolean gainNewData();

}
