package com.example.demo.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.example.demo.entity.Org;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Description:
 * @Author: wangyongqiang13
 * @Date: 2020/9/2 8:57
 */
public interface OrgMapper extends BaseMapper<Org> {
}
