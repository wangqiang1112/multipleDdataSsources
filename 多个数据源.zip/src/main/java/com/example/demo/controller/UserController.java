package com.example.demo.controller;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.example.demo.entity.Org;
import com.example.demo.entity.User;
import com.example.demo.mapper.OrgMapper;
import com.example.demo.service.IOrgService;
import com.example.demo.service.IUserService;
import org.apache.catalina.mbeans.UserMBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @Description:
 * @Author: wangyongqiang13
 * @Date: 2020/9/1 19:47
 */
@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private IUserService userService;

    @GetMapping(value = "/user")
    @ResponseBody
    public String user() {
        List<User> userList = userService.selectList(null);
        return JSONObject.toJSONString(userList);
    }

}
