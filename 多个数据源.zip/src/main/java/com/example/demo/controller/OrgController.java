package com.example.demo.controller;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.example.demo.entity.Org;
import com.example.demo.entity.User;
import com.example.demo.service.IOrgService;
import com.example.demo.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @Description:
 * @Author: wangyongqiang13
 * @Date: 2020/9/1 19:47
 */
@RestController
@RequestMapping("/org")
public class OrgController {

    @Autowired
    private IOrgService orgService;

    @GetMapping(value = "/org")
    public String org() {
        EntityWrapper ew = new EntityWrapper();
        List<Org> orgList = orgService.selectList(ew);
        return JSONObject.toJSONString(orgList);
    }

}
