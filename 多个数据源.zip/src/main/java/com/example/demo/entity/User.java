package com.example.demo.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Data;

/**
 * @Description:
 * @Author: wangyongqiang13
 * @Date: 2020/9/1 19:50
 */
@Data
@TableName("tb_user")
public class User {

    @TableId("user_id")
    private String userId;

    @TableField("user_name")
    private String userName;

}
