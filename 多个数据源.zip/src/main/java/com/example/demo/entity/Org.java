package com.example.demo.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Data;

/**
 * @Description:
 * @Author: wangyongqiang13
 * @Date: 2020/9/2 8:58
 */
@Data
@TableName("tb_org")
public class Org {

    @TableId("org_id")
    private String orgId;

    @TableField("org_name")
    private String orgName;

}
