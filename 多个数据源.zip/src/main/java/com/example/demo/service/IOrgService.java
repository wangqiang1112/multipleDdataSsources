package com.example.demo.service;

import com.baomidou.mybatisplus.service.IService;
import com.example.demo.entity.Org;
import com.example.demo.entity.User;

/**
 * @Description:
 * @Author: wangyongqiang13
 * @Date: 2020/9/1 19:49
 */
public interface IOrgService extends IService<Org> {
}
