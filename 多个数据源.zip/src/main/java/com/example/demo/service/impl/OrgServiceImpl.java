package com.example.demo.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.example.demo.entity.Org;
import com.example.demo.mapper.OrgMapper;
import com.example.demo.service.IOrgService;
import org.springframework.stereotype.Service;

/**
 * @Description:
 * @Author: wangyongqiang13
 * @Date: 2020/9/1 19:50
 */
@Service
public class OrgServiceImpl extends ServiceImpl<OrgMapper, Org> implements IOrgService {
}
