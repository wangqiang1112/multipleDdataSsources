package com.example.demo.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.example.demo.entity.User;
import com.example.demo.service.IUserService;
import com.example.demo.mapperSource.UserMapper;
import org.springframework.stereotype.Service;

/**
 * @Description:
 * @Author: wangyongqiang13
 * @Date: 2020/9/1 19:50
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements IUserService {
}
