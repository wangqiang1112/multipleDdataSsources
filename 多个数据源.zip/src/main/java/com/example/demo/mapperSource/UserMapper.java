package com.example.demo.mapperSource;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.example.demo.entity.User;

/**
 * @Description:
 * @Author: wangyongqiang13
 * @Date: 2020/9/2 8:57
 */
public interface UserMapper extends BaseMapper<User> {
}
