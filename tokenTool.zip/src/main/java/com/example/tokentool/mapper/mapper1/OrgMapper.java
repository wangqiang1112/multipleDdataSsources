package com.example.tokentool.mapper.mapper1;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.example.tokentool.entity.Org;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Description:
 * @Author: wangyongqiang13
 * @Date: 2020/9/2 8:57
 */
public interface OrgMapper extends BaseMapper<Org> {
}
