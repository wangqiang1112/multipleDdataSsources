package com.example.tokentool.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.example.tokentool.entity.Org;
import com.example.tokentool.mapper.mapper1.OrgMapper;
import com.example.tokentool.service.IOrgService;
import org.springframework.stereotype.Service;

/**
 * @Description:
 * @Author: wangyongqiang13
 * @Date: 2020/9/1 19:50
 */
@Service
public class OrgServiceImpl extends ServiceImpl<OrgMapper, Org> implements IOrgService {
}
