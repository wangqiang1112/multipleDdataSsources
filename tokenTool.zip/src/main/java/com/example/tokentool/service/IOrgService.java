package com.example.tokentool.service;

import com.baomidou.mybatisplus.service.IService;
import com.example.tokentool.entity.Org;

/**
 * @Description:
 * @Author: wangyongqiang13
 * @Date: 2020/9/1 19:49
 */
public interface IOrgService extends IService<Org> {
}
