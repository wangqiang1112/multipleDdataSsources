package com.example.tokentool.controller;

import com.alibaba.fastjson.JSONObject;
import com.example.tokentool.entity.Org;
import com.example.tokentool.service.IOrgService;
import com.example.tokentool.thread.AsyncTask;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


/**
 * @Auther: wangyongqiang13
 * @Date: 2020/4/24 8:49
 * @Description:
 */
@RestController
@RequestMapping("/thread")
@Api(tags = "线程池测试", description = "线程池测试")
public class ThreadController {

    @Autowired
    private AsyncTask asyncTask;


    @ResponseBody
    @RequestMapping(value = "/threadTest", method = RequestMethod.GET)
    @ApiOperation(value = "测试", notes = "测试接口说明")
    public String threadTest() {

        for(int i = 0;i < 1000;i++){
            asyncTask.tesTask(i);
            /*if(i % 2 == 0){
                asyncTask.tesTask(i);
            }else {
                asyncTask.stringTask(i+"-奇数");
            }*/
        }



        return "";
    }

}
