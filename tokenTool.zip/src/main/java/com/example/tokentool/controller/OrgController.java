package com.example.tokentool.controller;

import com.alibaba.fastjson.JSONObject;
import com.example.tokentool.entity.Org;
import com.example.tokentool.service.IOrgService;
import com.example.tokentool.utils.BicUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


/**
 * @Auther: wangyongqiang13
 * @Date: 2020/4/24 8:49
 * @Description:
 */
@RestController
@RequestMapping("/multipleDataSources")
@Api(tags = "多数据源", description = "多数据源")
public class OrgController {

    @Autowired
    private IOrgService orgService;

    @ResponseBody
    @RequestMapping(value = "/queryOrgList", method = RequestMethod.POST)
    @ApiOperation(value = "获取组织列表", notes = "获取组织列表接口说明")
    public String queryOrgList() {
        List<Org> list = orgService.selectList(null);
        return JSONObject.toJSONString(list);
    }

}
