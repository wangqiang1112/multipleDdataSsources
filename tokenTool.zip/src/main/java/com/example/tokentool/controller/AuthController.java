package com.example.tokentool.controller;

import com.example.tokentool.utils.BicUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;


/**
 * @Auther: wangyongqiang13
 * @Date: 2020/4/24 8:49
 * @Description:
 */
@RestController
@RequestMapping("/auth")
@Api(tags = "权限认证", description = "权限认证")
public class AuthController {


    @ResponseBody
    @RequestMapping(value = "/getTokenLinux", method = RequestMethod.POST)
    @ApiOperation(value = "获取linux的token", notes = "获取linux的token接口说明")
    public String getTokenLinux() {
        return BicUtil.identifyEx(null);
    }

    @ResponseBody
    @RequestMapping(value = "/getTokenWindows", method = RequestMethod.POST)
    @ApiOperation(value = "获取Windows的token", notes = "获取Windows的token接口说明")
    public String getTokenWindows() {
        return BicUtil.identify(null);
    }


}
