//package com.example.tokentool.config;
//
//import com.baomidou.mybatisplus.extension.parsers.ITableNameHandler;
//import org.apache.ibatis.reflection.MetaObject;
//import org.springframework.stereotype.Component;
//
///**
// * @Description: mybatisplus分表查询配置表名
// * @Author: wangyongqiang13
// * @Date: 2020/11/21 10:31
// */
//@Component
//public class MyDynamicTableNameParser implements ITableNameHandler {
//
//    public static String tableNameSuffix = "";
//
//    @Override
//    public String dynamicTableName(MetaObject metaObject, String sql, String tableName) {
//
//        // 加上分表逻辑后缀
//        if("".equals(tableNameSuffix)){
//            return tableName;
//        }else {
//            return tableName+"_"+tableNameSuffix;
//        }
//    }
//
//}
