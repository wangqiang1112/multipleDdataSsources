//package com.example.tokentool.config;
//
//import com.baomidou.mybatisplus.core.parser.ISqlParser;
//import com.baomidou.mybatisplus.extension.parsers.DynamicTableNameParser;
//import com.baomidou.mybatisplus.extension.parsers.ITableNameHandler;
//import com.baomidou.mybatisplus.extension.plugins.PaginationInterceptor;
//import org.mybatis.spring.annotation.MapperScan;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//
///**
// * 描述：mybatisplus分表查询插件配置
// * @Date: Created in 10:05 2020/5/21
// * @since jdk1.8
// */
//@Configuration
//@MapperScan("com.hikvision.**.mapper*")
//public class MybatisPlusConfig {
//
//    private final MyDynamicTableNameParser myDynamicTableNameParser;
//
//    public MybatisPlusConfig(MyDynamicTableNameParser myDynamicTableNameParser) {
//        this.myDynamicTableNameParser = myDynamicTableNameParser;
//    }
//
//
//
//    @Bean
//    public PaginationInterceptor paginationInterceptor() {
//        // 分页
//        PaginationInterceptor page = new PaginationInterceptor();
//
//        // 分表
//        dynamicTableNameParser(page);
//        return page;
//    }
//
//
//    /**
//     * 分表
//     */
//    private void dynamicTableNameParser(PaginationInterceptor page) {
//
//        // 为指定表设置动态表名处理器
//        HashMap<String, ITableNameHandler> map = new HashMap<>(3);
//        //配置需要分表得原表表名称
//        map.put("tb_vehicle_detail", myDynamicTableNameParser);
//
//        // 将需要处理的表添加到动态表名 SQL 解析器
//        DynamicTableNameParser dynamicTableNameParser = new DynamicTableNameParser();
//        dynamicTableNameParser.setTableNameHandlerMap(map);
//
//        // 加入处理器链中
//        List<ISqlParser> iSqlParsers = new ArrayList<>();
//        iSqlParsers.add(dynamicTableNameParser);
//        page.setSqlParserList(iSqlParsers);
//
//    }
//
//
//
//
//
//}
