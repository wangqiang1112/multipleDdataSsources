package com.example.tokentool.mq;

import org.apache.activemq.command.ActiveMQTextMessage;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import javax.jms.Message;

/**
 * @Description:
 * @Author: wangyongqiang13
 * @Date: 2020/10/29 18:17
 */
@Component
public class ActiveMQConsumer {

    @JmsListener(destination = "mbs.mbsweb.topic.res_change",containerFactory = "topicListener")
    public void receive(Message message){
        ActiveMQTextMessage objectMsg = (ActiveMQTextMessage)message;
        try {
            System.out.println(objectMsg.getText());
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }
    }

}
