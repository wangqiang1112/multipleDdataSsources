package com.example.tokentool.init;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * @Description:
 * @Author: wangyongqiang13
 * @Date: 2020/10/9 10:38
 */
//@Component
public class testCommand implements CommandLineRunner {
    @Override
    public void run(String... args) throws Exception {

        System.out.println("启动任务开启。。。");

        try {
            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    while (true){
                        try {
                            System.out.println(new Date().getTime());
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            });
            thread.start();
        } catch (Exception e) {
        }

    }
}
