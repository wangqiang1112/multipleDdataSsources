package com.example.tokentool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TokenToolApplication {

    public static void main(String[] args) {
        SpringApplication.run(TokenToolApplication.class, args);
    }

}
