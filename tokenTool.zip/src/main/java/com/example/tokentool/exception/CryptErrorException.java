package com.example.tokentool.exception;

/**
 * @Description:
 * @Author: wangyongqiang13
 * @Date: 2020/9/30 10:00
 */
public class CryptErrorException extends Exception {

    private static final long serialVersionUID = 7606191958807771992L;
    private String code = "0";
    private String msg;

    public CryptErrorException() {
    }

    public CryptErrorException(Throwable e) {
        super(e);
    }

    public CryptErrorException(Throwable e, String code) {
        super(e);
        this.code = code;
    }

    public CryptErrorException(String msg) {
        super(msg);
        this.msg = msg;
    }

    public CryptErrorException(String msg, String code) {
        super(msg);
        this.msg = msg;
        this.code = code;
    }

    public CryptErrorException(String msg, Throwable e) {
        super(msg, e);
        this.msg = msg;
    }

    public CryptErrorException(String code, String msg, Throwable e) {
        super(msg, e);
        this.code = code;
        this.msg = msg;
    }

    public String getCode() {
        return this.code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return this.msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

}
