package com.example.tokentool.utils;


import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.binary.StringUtils;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.codec.digest.HmacUtils;
import org.springframework.util.ObjectUtils;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.UUID;

public class CodecUtil {

	public static final String  DEFAULT_SYMMETRIC  ="AES";



	/**
	 *
	 * @param str  字符串和字节相互转换
	 * @return
	 */
	public static  byte[]  getBytes(String  str) {
		return  StringUtils.getBytesUtf8(str);
	}

	public static  byte[]  getBytes(String  str, String encoding)  {
		return StringUtils.getBytesUnchecked(str, encoding);
	}

	public static String getStr(byte[] buf)  {
		return   StringUtils.newStringUtf8(buf);
	}

	public static String getStr(byte[] buf, String encoding)  {
		return StringUtils.newString(buf, encoding);
	}


	/**
	 * base64编码处理
	 */

	public static String encodeBASE64(byte[] data) {
		return Base64.encodeBase64String(data);
	}


	public static byte[] decodeBASE64ToByte(String str) {
		return Base64.decodeBase64(str);
	}


	/**
	 * 16进制处理
	 * @param buf
	 * @return
	 */
	public static String toHex(byte[] buf) {
		return Hex.encodeHexString(buf);
	}

	public static byte[] hexStringToByte(String hexString)  {
		try {
		return 	Hex.decodeHex(hexString.toCharArray());
		}catch(DecoderException e){
			throw new RuntimeException("转换16进制异常:"+hexString);
		}
	}

	/**
	 * 获取 UUID（32位）
	 */
	public static String createUUID() {
		return UUID.randomUUID().toString().replaceAll("-", "");
	}

	/**
	 * Hash算法的处理
	 */
	public static String encryptMD5(String str) {
		return DigestUtils.md5Hex(str);
	}


	public static String encryptSHA256(String str) {
		return DigestUtils.sha256Hex(str);
	}



	public static byte[] HmacSHA1Encrypt(String encryptKey,String encryptText){
			byte[] encryptKeyData = getBytes(encryptKey);
			byte[] encryptData = getBytes(encryptText);
			return HmacUtils.hmacSha1(encryptKeyData,encryptData);
	}


	public static byte[] HmacSHA1Encrypt(byte[] encryptKeyData,byte[] encryptData)  {
		return HmacUtils.hmacSha1(encryptKeyData, encryptData);
	}



	public static byte[]  getKeyBySeed(String seed) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		KeyGenerator kgenerator = KeyGenerator.getInstance(DEFAULT_SYMMETRIC);
		SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
		secureRandom.setSeed(getBytes(seed));
		kgenerator.init(128, secureRandom);
		SecretKey s = kgenerator.generateKey();
		return s.getEncoded();
	}



	public static byte[] aesEncode(byte[] orgData, byte[] privateKey) throws Exception{
		return  aesEncode(orgData, privateKey, null, null);
	}


	private static SecretKeySpec bytestokey(byte[] keybuf){
		return  new SecretKeySpec(keybuf, DEFAULT_SYMMETRIC);
	}

	/**
	 * AES加密示例代码
	 * @param orgData
	 * @param keybuf
	 * @return
	 * @throws Exception
	 */
	public static byte[] aesEncode(byte[] orgData, byte[] keybuf ,String algorithmStr,String  ivCode) throws Exception {
		SecretKeySpec sskey =  bytestokey( keybuf);
		if(ObjectUtils.isEmpty(algorithmStr)){
			algorithmStr=DEFAULT_SYMMETRIC;
		}
		Cipher cipher = Cipher.getInstance(algorithmStr);// 创建密码器
		if(!ObjectUtils.isEmpty(ivCode)) {
			IvParameterSpec ivspec = new IvParameterSpec(getBytes(ivCode));
			cipher.init(Cipher.ENCRYPT_MODE, sskey, ivspec);
		}else {
			cipher.init(Cipher.ENCRYPT_MODE, sskey);
		}
		return cipher.doFinal(orgData);
	}



	public static byte[] aesDecode(byte[] orgData, byte[] privateKey) throws Exception{
		return  aesDecode(orgData, privateKey, null, null);
	}


	/**
	 * AES解密示例代码
	 * @param passedData
	 * @param keybuf
	 * @param  algorithmStr 加密参数 "AES/ECB/PKCS5Padding"
	 * @param   ivCode  初始化向量
	 * @return
	 * @throws Exception
	 */
	public static byte[] aesDecode(byte[] passedData, byte[] keybuf, String algorithmStr,String  ivCode) throws Exception {
		SecretKeySpec sskey =  bytestokey( keybuf);
		if(ObjectUtils.isEmpty(algorithmStr)){
			algorithmStr=DEFAULT_SYMMETRIC;
		}
		Cipher cipher = Cipher.getInstance(algorithmStr);// 创建密码器
		if(!ObjectUtils.isEmpty(ivCode)) {
			IvParameterSpec ivspec = new IvParameterSpec(getBytes(ivCode));
			cipher.init(Cipher.DECRYPT_MODE, sskey, ivspec);
		}else {
			cipher.init(Cipher.DECRYPT_MODE, sskey);
		}
		return cipher.doFinal(passedData);

	}



}
