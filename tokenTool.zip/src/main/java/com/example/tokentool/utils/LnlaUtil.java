package com.example.tokentool.utils;

import java.math.BigDecimal;
import java.time.Month;

/**
 * @Description: 距离转化经纬度
 * @Author: wangyongqiang13
 * @Date: 2020/11/9 14:14
 */
public class LnlaUtil {

    /**
     * 距离转换成经度
     * @param distance
     * @return
     */
    private static Double doLngDegress(Double distance,Double latitude) {
        double lngDegree = 2 * Math.asin(Math.sin(distance/12742)/Math.cos(latitude));
        // 转换弧度
        lngDegree = lngDegree * (180/Math.PI);
        System.out.println(lngDegree);
        return lngDegree;
    }

    /**
     * 距离转换成纬度
     * @param distance
     * @return
     */
    private static Double doLatDegress(double distance) {
        double latDegrees = distance/6371;
        // 转换弧度
        latDegrees = latDegrees * (180/Math.PI);

        BigDecimal b = new BigDecimal(latDegrees);
        latDegrees = b.setScale(6, BigDecimal.ROUND_HALF_UP).doubleValue();


        System.out.println(latDegrees);
        return latDegrees;
    }

    public static void main(String[] args) {

        doLngDegress(13369227.35577,31.890225478814354);
		doLatDegress(3546.0312827952);
    }



}
