/*
  * @ProjectName: 8730-dcms-thrunk-1.2
  * @Copyright: 2013 HangZhou Hikvision System Technology Co., Ltd. All Right Reserved.
  * @address: http://www.hikvision.com
  * @date: 2017/6/16
  * @Description: 本内容仅限于杭州海康威视系统技术有限公司内部使用，禁止转发.
*/
package com.example.tokentool.utils;

import com.google.common.base.Preconditions;
import com.hikvision.hik.crypt.Authentication;
import com.hikvision.hik.crypt.CryptErrorException;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

/**
 * 身份认证库工具类
 * <p>
 *
 * @since V1.2
 * Created by zhengjingguo on 2017/6/16.
 */
public class BicUtil {

    private final static Logger logger = LoggerFactory.getLogger(BicUtil.class);
    
	private static final Integer CONNECT_TIMEOUT = 3000;//连接超时时间
	private static final Integer READ_TIMEOUT = 10000;//读取超时时间
    /**
     * 请求身份，用于token
     * @param input 输入
     * @return 返回bic token
     */
    public static String identifyEx(String input) throws RuntimeException {
        try {
            byte[] identify = Authentication.identifyApplyEx(input);
            return Base64.encodeBase64String(identify);
        } catch (CryptErrorException e) {
            e.printStackTrace();
        }
        throw new RuntimeException("请求组件身份信息失败");
    }

    public static String identify(String input) throws RuntimeException {
        try {
            byte[] identify = Authentication.identifyApply(input);
            return CodecUtil.encodeBASE64(identify);
        } catch (CryptErrorException e) {
            logger.error("request identify error.");
            e.printStackTrace();
        }
        throw new RuntimeException("请求组件身份信息失败");
    }

    /**
     * 判断签名是否有效，防篡改
     *
     * @param signature 签名
     * @param input     原文
     * @return true : 通过， false ： 不通过
     */
    public static boolean signatureCheck(String signature, String input) {
        Preconditions.checkNotNull(signature);
        try {
            return "0".equals(Authentication.identifyCheck(CodecUtil.decodeBASE64ToByte(signature), input));
        } catch (CryptErrorException e) {
            logger.error("check signatureCheck error.");
            e.printStackTrace();
        }
        return false;
    }
    
    /**
     * Title getRestTemplate
	 * Description 	获取rpc实例，设置超时时间
     * @author fenghaoqi 2018年9月27日 上午10:36:52
     * @return
     * @version v1.0.0
     */
    public static RestTemplate getRestTemplate(){
		RestTemplate restTemplate = new RestTemplate();
		SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
		factory.setConnectTimeout(CONNECT_TIMEOUT);
		factory.setReadTimeout(READ_TIMEOUT);
		restTemplate.setRequestFactory(factory);
		return restTemplate;	
    }

}
