package com.example.tokentool.errorcode;

/**
 * @Description:
 * @Author: wangyongqiang13
 * @Date: 2020/9/30 9:59
 */
public enum CryptErrorCode {
    NO_SUCHALGORITHM_EXCEPTION("0x9001", "JRE Version problem and does not support this encryption"),
    INVALID_KEYSPEC_EXCEPTION("0x9002", "JRE Version problem,invalid keyspec for this cryption"),
    REGISTRATION_INCONSISTENT_EXCEPTION("0x9003", "Inconsistencies in the registry,Identify check is not passed."),
    LIB_VERSION_EXCEPTION("0x9004", "Library version is wrong,Identify check is not passed."),
    INPUT_DATA_LENGTH_EXCEPTION("0x9005", "The input data length is not correct,Identify check is not passed."),
    WIN_REGEDIT_READ_EXCEPTION("0x9006", "windows regit read fail"),
    REGEDIT_INCORRECT_EXCEPTION("0x9007", "regit incorrect"),
    AES_ENCRYPT_EXCEPTION("0x9008", "AES encrypt fail"),
    AES_DECRYPT_EXCEPTION("0x9009", "AES decrypt fail"),
    CLOADER_NOT_INIT_EXCEPTION("0x900a", "Cloader not init"),
    CLASS_READ_EXCEPTION("0x900b", "class file read fail"),
    IDENTIFY_APPLY_FAIL("0x900c", "identifyApply fail"),
    IDENTIFY_CHECK_FAIL("0x900d", "identifyCheck fail"),
    REGEDIT_READ_FAIL("0x900e", "identifyCheck fail"),
    TRANSDATA_ENCRYPT_FAIL("0x900f", "transDataEncrypt fail"),
    APPLY_SK_BY_AK_FAIL("0x900g", "apply sk by ak fail"),
    TRANSDATA_DECRYPT_FAIL("0x9010", "transDataDecrypt fail"),
    AK_LENGTH_NOT_MATCH("0x9011", "AK length is not 16"),
    SK_LENGTH_NOT_MATCH("0x9012", "SK length is not 32");

    private String errorCode;
    private String message;

    private CryptErrorCode(String errorCode, String message) {
        this.errorCode = errorCode;
        this.message = message;
    }

    public String getErrorCode() {
        return this.errorCode;
    }

    public String getMessage() {
        return this.message;
    }

}
